#include<stdio.h>
#include<string.h>
#include<stdlib.h>
float fA[100][2];
int nPareto[100];

int readCSVfile(){
  int i=0;
  FILE *pif;
  pif=fopen("a.csv","r");
  char str[1000], *pIn;
  do{
    fscanf(pif,"%s",str);
    pIn=strtok(str,";");//PointerToString=strtok(PointerToTheString,constCharAS delimiter)
    while(pIn != NULL){
      *(((float *)fA)+(i++))=atof(pIn);
      pIn =strtok(NULL,";"); //to a new data
    }
  } while (fgetc(pif)!=EOF);
  return i;
}

int main(){

  int nNbObjectives=2, nComplexity=0;
  int nNbReadValues=readCSVfile();
  for (int i=0;i<nNbReadValues/2;i++) nPareto[i]=-1;
  for(int i=0;i<nNbReadValues/2;i++){
    printf("%f \t",fA[i][0]);
    printf("%f \t",fA[i][1]);
    printf("\n");
  }

  printf("Calculating the Pareto front\n");

	int count=0,z=0;
  
  for(int x=0;x<21;x++){
  	for(int y=0;y<21;y++){
  		if(fA[x][0]>fA[y][0] && fA[x][1]>fA[y][1]){
			count=0;
			break;	
		}
		else count++;
	}
	if(count==21){ nPareto[z++]=x;count=0;}
  }
  for(int i=0;i<nNbReadValues/2;i++){
    if (nPareto[i]>-1){
      printf("%f \t",fA[nPareto[i]][0]);
      printf("%f \t",fA[nPareto[i]][1]);
      printf("\n");
    }
  }
  printf("Complexity = %d\n",nComplexity);

  printf("\n");
  return 0;
}
