#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int nPareto[100];
float mat[200];

int main(){
    int i=0;
  FILE *pif;
  pif=fopen("mn.csv","r");
  char str[1000], *pIn;
  do{
      for(int j=0;j<10;j++)   
        fscanf(pif,"%[^;];",str);
      fscanf(pif,"%s",str);
     // fscanf(pif,"%[^\n]\n",str);
      if(str != NULL) 
         mat[i++]=atof(str);
  } while (fgetc(pif)!=EOF);

   for(int j=0;j<i;j++)
      printf("%f\n",mat[j]);
   printf("%d\n",i);

}
