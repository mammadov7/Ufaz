#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int nPareto[100];
float mat[100][2];

int main(){
    int bChallengerIsDominant,bCandidateIsDominant;
    char buffer[1024];
    char *record,*line;
    int i=0,t, nDominant =0,nRank=1;
   
    FILE *fstream = fopen("a.csv","r");
    while((line=fgets(buffer,sizeof(buffer),fstream))){
       int j=0;
        record = strtok(line,";");
        while(record != NULL){
            mat[i][j++] = atof(record);
            record = strtok(NULL,";");
            t=j;
        }
        ++i;
    }    // t number of points
    int numberOfIndividuals=i;
    for(int j=0;j<i;j++) nPareto[j]=-1;
    
    while(numberOfIndividuals>0){
        for(int nCandidate=0;nCandidate<numberOfIndividuals;nCandidate++){
            bCandidateIsDominant=1;
            for(int nChallenger=0;nChallenger<numberOfIndividuals;nChallenger++){
            //    if(nCandidate==nChallenger)       continue;
                bChallengerIsDominant=1;
                for(int m=0;m<t;m++)
                    if(mat[nChallenger][m]>=mat[nCandidate][m]) bChallengerIsDominant=0;
            if(bChallengerIsDominant){
                bCandidateIsDominant=0;
            // break;
            } 
        }
            if(bCandidateIsDominant) nPareto[nDominant++]=nCandidate;
        }
        printf("Rank is: %d\n",nRank++);
        for(int j=0;j<i;j++){
            if(nPareto[j]>-1){
                printf("%f\t",mat[nPareto[j]][0]);
                printf("%f\n",mat[nPareto[j]][1]);
            }
        }

        for(int j=0;j<i;j++){
            int k=0;
            for(;k<i;k++) 
                if(nPareto[k]==(numberOfIndividuals-1)){ 
                    numberOfIndividuals--;
                    nPareto[k]=-1;
                    k=0;
                }
            if(nPareto[j]>-1){
                mat[nPareto[j]][0]=mat[numberOfIndividuals-1][0];
                mat[nPareto[j]][1]=mat[numberOfIndividuals-1][1];
                numberOfIndividuals--;
                }
            }
          for(int j=0;j<i;j++) nPareto[j]=-1;
    } 
   return 0;
 }